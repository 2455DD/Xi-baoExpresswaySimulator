package object;

import object.Station;

public class Passenger {    
		Station target;
	    Passenger(Station tar){
	    	this.target=tar;
	    }
}
