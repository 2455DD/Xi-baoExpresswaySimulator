package object;
import object.*;
public class Station<E> {
	private static String Fullname;
    private static String Name;
    Queue<E> carrierQueue;
    Queue<Passenger> passengerInStation;
    private int DistanceToFormer;
    private int DistanceToLatter;
    private int passengerDownload=0;
    Station<E> next;
    Station<E> before;
    //Constructor
    Station(String fn,String n,int dtf,int dtl,Station<E> latter,Station<E> former){
    	this.Fullname=fn;
    	this.Name=n;
    	this.DistanceToFormer=dtf;
    	this.DistanceToLatter=dtl;
    	this.before=former;
    	this.next=latter;
    }
    //Method
    public String returnNextStation() {
    	return this.next.Name;
    }
    public String returnBeforeStation() {
    	return this.before.Name;
    }
    public void carrierArrive(E Obj1) {
    	;
    }
    public void carrierStart(E obj1) {
    	
    }
    public String returnName() {return this.Name;}
    
}
