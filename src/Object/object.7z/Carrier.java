package object;

import object.*;
public class Carrier {
	//����
    private int DistanceToFormerStation;
    protected int maximumPassenger;
    private Station nextStation;
    private Queue<Passenger> passengerQueue;
    private boolean queueIsFull=false;
    int target;
    //����
    public int returnLocation(int time) {
    	return 1;
    }
    public boolean isFull() {
    	if(passengerQueue.size()==maximumPassenger)queueIsFull=true;
    	return queueIsFull;
    	}
    public void leaveStation(int new_distance) {
    	this.maximumPassenger=new_distance;
    }
}
class Car extends Carrier{
	double speed;
	
}
class Volve extends Car{
	Volve(){
		speed=2;
		maximumPassenger=40;
	}
}